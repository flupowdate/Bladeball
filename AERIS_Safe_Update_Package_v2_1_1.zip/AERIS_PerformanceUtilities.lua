-- AERIS_PerformanceUtilities.lua
-- Safe Roblox Studio utility module.
-- This module does NOT hook executor APIs, spoof devices, intercept remotes,
-- or automate gameplay. It provides lifecycle-safe connections and throttling
-- for UI, visual effects, and developer diagnostics in projects you own.

local RunService = game:GetService("RunService")

local AERISPerformance = {}
AERISPerformance.__index = AERISPerformance

local function now()
	return os.clock()
end

-- Creates a cleanup scope for connections, instances, and cleanup callbacks.
function AERISPerformance.new()
	return setmetatable({
		_items = {},
		_destroyed = false,
	}, AERISPerformance)
end

function AERISPerformance:Add(item)
	assert(not self._destroyed, "AERISPerformance scope is destroyed")
	table.insert(self._items, item)
	return item
end

function AERISPerformance:Connect(signal, callback)
	assert(typeof(signal) == "RBXScriptSignal", "Expected RBXScriptSignal")
	local connection = signal:Connect(callback)
	self:Add(connection)
	return connection
end

function AERISPerformance:Destroy()
	if self._destroyed then
		return
	end
	self._destroyed = true

	for i = #self._items, 1, -1 do
		local item = self._items[i]
		local kind = typeof(item)

		if kind == "RBXScriptConnection" then
			if item.Connected then
				item:Disconnect()
			end
		elseif kind == "Instance" then
			if item.Parent ~= nil then
				item:Destroy()
			end
		elseif type(item) == "function" then
			pcall(item)
		elseif type(item) == "table" and type(item.Destroy) == "function" then
			pcall(function()
				item:Destroy()
			end)
		end

		self._items[i] = nil
	end
end

-- Calls callback at most once per interval; useful for non-critical UI refreshes.
function AERISPerformance.Throttle(interval, callback)
	assert(type(interval) == "number" and interval >= 0, "interval must be >= 0")
	assert(type(callback) == "function", "callback must be a function")

	local lastCall = -math.huge
	return function(...)
		local t = now()
		if t - lastCall < interval then
			return false
		end
		lastCall = t
		callback(...)
		return true
	end
end

-- Runs a callback on a fixed cadence without accumulating a backlog.
-- Returns a connection; disconnect it when the owning UI/component is removed.
function AERISPerformance.FixedStep(interval, callback, signal)
	assert(type(interval) == "number" and interval > 0, "interval must be > 0")
	assert(type(callback) == "function", "callback must be a function")

	signal = signal or RunService.Heartbeat
	local elapsed = 0

	return signal:Connect(function(dt)
		elapsed += dt
		if elapsed < interval then
			return
		end

		-- Drop excess accumulated time rather than running multiple catch-up updates.
		local step = elapsed
		elapsed = 0
		callback(step)
	end)
end

-- Simple frame-time sampler for diagnostics; it reports measurements only.
function AERISPerformance.FrameSampler(sampleSeconds, callback)
	assert(type(sampleSeconds) == "number" and sampleSeconds > 0, "sampleSeconds must be > 0")
	assert(type(callback) == "function", "callback must be a function")

	local elapsed = 0
	local frames = 0
	local totalDt = 0
	local worstDt = 0

	return RunService.Heartbeat:Connect(function(dt)
		frames += 1
		totalDt += dt
		if dt > worstDt then
			worstDt = dt
		end
		elapsed += dt

		if elapsed >= sampleSeconds then
			local avgDt = totalDt / math.max(frames, 1)
			callback({
				fpsAverage = avgDt > 0 and (1 / avgDt) or 0,
				frameTimeAverageMs = avgDt * 1000,
				frameTimeWorstMs = worstDt * 1000,
				samples = frames,
				windowSeconds = elapsed,
			})

			elapsed = 0
			frames = 0
			totalDt = 0
			worstDt = 0
		end
	end)
end

return AERISPerformance
