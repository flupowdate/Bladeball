--[[
    AERIS Training Replay Analyzer v2.1.0
    BASE: AERIS Training Replay Analyzer v1.0.0
    Purpose: Offline replay diagnostics and trajectory-quality analysis.

    Safety: Advisory/offline only. This module does not automate input,
    call remotes, install hooks, or control a live game.

    Input:
      session = {
        samples = {
          { t = 0.0, ballPosition = Vector3, playerPosition = Vector3,
            pingMs = 45, frameTimeMs = 16.7 },
          ...
        },
        events = {
          { t = 1.25, kind = "parry_attempt" },
          { t = 1.41, kind = "hit" },
          ...
        }
      }

    All timestamps must use one monotonic clock and seconds.
]]

local Analyzer = {}
Analyzer.VERSION = "2.1.0"
Analyzer.BASE_VERSION = "1.0.0"

local DEFAULTS = {
    minSamples = 3,
    maxSamples = 2400,
    maxEvents = 1200,
    maxGapSeconds = 0.25,
    maxSpeedForOutlier = 10000,
    timingWindowSeconds = 0.35,
    maxEventPairSeconds = 1.50,
    maxWarnings = 12,
}

local LIMITS = {
    minSamples = { 2, 2400 },
    maxSamples = { 2, 2400 },
    maxEvents = { 0, 1200 },
    maxGapSeconds = { 0.01, 5 },
    maxSpeedForOutlier = { 1, 100000 },
    timingWindowSeconds = { 0.01, 5 },
    maxEventPairSeconds = { 0.05, 10 },
    maxWarnings = { 1, 30 },
}

local function finiteNumber(value)
    return type(value) == "number"
        and value == value
        and value > -math.huge
        and value < math.huge
end

local function clamp(value, low, high)
    return math.max(low, math.min(high, value))
end

local function isVector3(value)
    return typeof(value) == "Vector3"
        and finiteNumber(value.X)
        and finiteNumber(value.Y)
        and finiteNumber(value.Z)
end

local function safeConfig(userConfig)
    local result = {}
    userConfig = type(userConfig) == "table" and userConfig or {}

    for key, fallback in pairs(DEFAULTS) do
        local value = userConfig[key]
        local bounds = LIMITS[key]
        if finiteNumber(value) then
            result[key] = clamp(value, bounds[1], bounds[2])
        else
            result[key] = fallback
        end
    end

    result.minSamples = math.floor(result.minSamples)
    result.maxSamples = math.max(result.minSamples, math.floor(result.maxSamples))
    result.maxEvents = math.floor(result.maxEvents)
    result.maxWarnings = math.floor(result.maxWarnings)
    return result
end

local function copyArray(values)
    local result = table.create(#values)
    for index, value in ipairs(values) do
        result[index] = value
    end
    return result
end

local function mean(values)
    if #values == 0 then return 0 end
    local sum = 0
    for _, value in ipairs(values) do sum += value end
    return sum / #values
end

local function median(values)
    if #values == 0 then return 0 end
    local sorted = copyArray(values)
    table.sort(sorted)
    local middle = math.floor((#sorted + 1) / 2)
    if #sorted % 2 == 1 then
        return sorted[middle]
    end
    return (sorted[middle] + sorted[middle + 1]) * 0.5
end

local function percentile(values, fraction)
    if #values == 0 then return 0 end
    local sorted = copyArray(values)
    table.sort(sorted)
    local index = clamp(math.ceil(#sorted * fraction), 1, #sorted)
    return sorted[index]
end

local function validateSamples(samples, config)
    if type(samples) ~= "table" then
        return nil, "samples must be a table"
    end

    local count = #samples
    if count < config.minSamples then return nil, "not enough samples" end
    if count > config.maxSamples then return nil, "sample limit exceeded" end

    local clean = table.create(count)
    local previousTime = -math.huge
    local optionalInvalid = 0

    for index, sample in ipairs(samples) do
        if type(sample) ~= "table"
            or not finiteNumber(sample.t)
            or not isVector3(sample.ballPosition)
            or not isVector3(sample.playerPosition) then
            return nil, "invalid required sample data at index " .. tostring(index)
        end
        if sample.t <= previousTime then
            return nil, "timestamps must be strictly increasing"
        end

        local ping = sample.pingMs
        local frame = sample.frameTimeMs
        if ping ~= nil and (not finiteNumber(ping) or ping < 0 or ping > 10000) then
            ping = nil
            optionalInvalid += 1
        end
        if frame ~= nil and (not finiteNumber(frame) or frame <= 0 or frame > 1000) then
            frame = nil
            optionalInvalid += 1
        end

        clean[index] = {
            t = sample.t,
            ballPosition = sample.ballPosition,
            playerPosition = sample.playerPosition,
            pingMs = ping,
            frameTimeMs = frame,
        }
        previousTime = sample.t
    end

    return clean, nil, optionalInvalid
end

local function calculateMotion(samples, config)
    local gaps, speeds, accelerations = {}, {}, {}
    local distances, turns, closingSpeeds = {}, {}, {}
    local pingValues, frameValues = {}, {}
    local validSegments, rejectedGap, rejectedSpeed = 0, 0, 0
    local previousVelocity = nil
    local previousDirection = nil
    local previousValidTime = nil
    local minimumDistance = math.huge
    local maximumDistance = 0

    for index, sample in ipairs(samples) do
        if sample.pingMs then pingValues[#pingValues + 1] = sample.pingMs end
        if sample.frameTimeMs then frameValues[#frameValues + 1] = sample.frameTimeMs end

        local distance = (sample.ballPosition - sample.playerPosition).Magnitude
        distances[#distances + 1] = distance
        minimumDistance = math.min(minimumDistance, distance)
        maximumDistance = math.max(maximumDistance, distance)

        if index > 1 then
            local previous = samples[index - 1]
            local dt = sample.t - previous.t
            gaps[#gaps + 1] = dt

            if dt <= 0 or dt > config.maxGapSeconds then
                rejectedGap += 1
                -- Critical: never bridge velocity, acceleration or heading
                -- across a discontinuity / long sampling gap.
                previousVelocity = nil
                previousDirection = nil
                previousValidTime = nil
            else
                local displacement = sample.ballPosition - previous.ballPosition
                local magnitude = displacement.Magnitude
                local velocity = displacement / dt
                local speed = velocity.Magnitude

                if finiteNumber(speed) and speed <= config.maxSpeedForOutlier then
                    validSegments += 1
                    speeds[#speeds + 1] = speed

                    local previousDistance = (previous.ballPosition - previous.playerPosition).Magnitude
                    local currentDistance = (sample.ballPosition - sample.playerPosition).Magnitude
                    -- Positive means the ball-player separation is shrinking.
                    closingSpeeds[#closingSpeeds + 1] = (previousDistance - currentDistance) / dt

                    if previousVelocity and previousValidTime then
                        local accelDt = sample.t - previousValidTime
                        if accelDt > 0 and accelDt <= config.maxGapSeconds * 1.5 then
                            local acceleration = (velocity - previousVelocity).Magnitude / accelDt
                            if finiteNumber(acceleration) then
                                accelerations[#accelerations + 1] = acceleration
                            end
                        end
                    end

                    if magnitude > 1e-5 then
                        local direction = displacement.Unit
                        if previousDirection then
                            local dot = clamp(previousDirection:Dot(direction), -1, 1)
                            turns[#turns + 1] = math.deg(math.acos(dot))
                        end
                        previousDirection = direction
                    end

                    previousVelocity = velocity
                    previousValidTime = sample.t
                else
                    rejectedSpeed += 1
                    previousVelocity = nil
                    previousDirection = nil
                    previousValidTime = nil
                end
            end
        end
    end

    local segmentCount = math.max(0, #samples - 1)
    local rejectedSegments = rejectedGap + rejectedSpeed
    local coverage = segmentCount > 0 and validSegments / segmentCount or 0
    local duration = samples[#samples].t - samples[1].t
    local avgGap = mean(gaps)

    return {
        sampleCount = #samples,
        durationSeconds = duration,
        segmentCount = segmentCount,
        validSegments = validSegments,
        rejectedSegments = rejectedSegments,
        rejectedGapSegments = rejectedGap,
        rejectedSpeedSegments = rejectedSpeed,
        sampleCoverage = coverage,
        averageSampleGapMs = avgGap * 1000,
        medianSampleGapMs = median(gaps) * 1000,
        p95SampleGapMs = percentile(gaps, 0.95) * 1000,
        maxSampleGapMs = percentile(gaps, 1) * 1000,
        averageBallSpeed = mean(speeds),
        medianBallSpeed = median(speeds),
        p95BallSpeed = percentile(speeds, 0.95),
        peakBallSpeed = percentile(speeds, 1),
        averageBallAcceleration = mean(accelerations),
        p95BallAcceleration = percentile(accelerations, 0.95),
        averageDistance = mean(distances),
        minimumDistance = minimumDistance == math.huge and 0 or minimumDistance,
        maximumDistance = maximumDistance,
        averageHeadingChangeDegrees = mean(turns),
        p95HeadingChangeDegrees = percentile(turns, 0.95),
        averageClosingSpeed = mean(closingSpeeds),
        pingSampleCount = #pingValues,
        averagePingMs = mean(pingValues),
        p95PingMs = percentile(pingValues, 0.95),
        frameTimeSampleCount = #frameValues,
        averageFrameTimeMs = mean(frameValues),
        p95FrameTimeMs = percentile(frameValues, 0.95),
    }
end

local function analyzeEvents(events, config)
    local result = {
        attempts = 0,
        hits = 0,
        otherOutcomes = 0,
        unmatchedAttempts = 0,
        unmatchedHits = 0,
        attemptToHitIntervalsMs = {},
        attemptsWithinWindow = 0,
        notes = {
            "Attempt-to-hit intervals are descriptive correlations, not proof of cause or correct timing.",
        },
    }

    if events == nil then return result end
    if type(events) ~= "table" then return nil, "events must be a table" end
    if #events > config.maxEvents then return nil, "event limit exceeded" end

    local ordered = table.create(#events)
    local previousInputOrder = 0
    for index, event in ipairs(events) do
        if type(event) ~= "table"
            or not finiteNumber(event.t)
            or type(event.kind) ~= "string" then
            return nil, "invalid event at index " .. tostring(index)
        end
        ordered[index] = { t = event.t, kind = event.kind, inputOrder = index }
        previousInputOrder = index
    end

    table.sort(ordered, function(a, b)
        if a.t == b.t then return a.inputOrder < b.inputOrder end
        return a.t < b.t
    end)

    local pendingAttempt = nil
    for _, event in ipairs(ordered) do
        if event.kind == "parry_attempt" then
            result.attempts += 1
            if pendingAttempt then result.unmatchedAttempts += 1 end
            pendingAttempt = event.t
        elseif event.kind == "hit" then
            result.hits += 1
            if pendingAttempt then
                local interval = event.t - pendingAttempt
                if interval >= 0 and interval <= config.maxEventPairSeconds then
                    local milliseconds = interval * 1000
                    result.attemptToHitIntervalsMs[#result.attemptToHitIntervalsMs + 1] = milliseconds
                    if interval <= config.timingWindowSeconds then
                        result.attemptsWithinWindow += 1
                    end
                else
                    result.unmatchedAttempts += 1
                    result.unmatchedHits += 1
                end
                pendingAttempt = nil
            else
                result.unmatchedHits += 1
            end
        else
            result.otherOutcomes += 1
        end
    end

    if pendingAttempt then result.unmatchedAttempts += 1 end
    result.pairedCount = #result.attemptToHitIntervalsMs
    result.medianAttemptToHitMs = median(result.attemptToHitIntervalsMs)
    result.p95AttemptToHitMs = percentile(result.attemptToHitIntervalsMs, 0.95)
    return result
end

local function buildWarnings(motion, events, optionalInvalid, config)
    local warnings = {}
    local function add(message)
        if #warnings < config.maxWarnings then
            warnings[#warnings + 1] = message
        end
    end

    if motion.sampleCoverage < 0.80 then
        add("Low valid-segment coverage: many intervals were rejected.")
    end
    if motion.p95SampleGapMs > 100 then
        add("Large sampling gaps can hide rapid trajectory changes.")
    end
    if motion.rejectedGapSegments > 0 then
        add("Metrics were reset across long gaps to avoid false acceleration/turn estimates.")
    end
    if motion.rejectedSpeedSegments > 0 then
        add("Some extreme-speed segments were excluded as possible outliers.")
    end
    if motion.sampleCount < 10 then
        add("Short replay: statistical summaries are preliminary.")
    end
    if optionalInvalid > 0 then
        add(tostring(optionalInvalid) .. " invalid optional telemetry value(s) were ignored.")
    end
    if events.unmatchedAttempts + events.unmatchedHits > 0 then
        add("Some events could not be paired within the configured descriptive window.")
    end
    if motion.pingSampleCount == 0 then
        add("No ping telemetry supplied; network latency cannot be assessed.")
    end
    if motion.frameTimeSampleCount == 0 then
        add("No frame-time telemetry supplied; rendering smoothness cannot be assessed.")
    end
    return warnings
end

function Analyzer.GetDefaults()
    local result = {}
    for key, value in pairs(DEFAULTS) do result[key] = value end
    return result
end

function Analyzer.AnalyzeSession(session, userConfig)
    if type(session) ~= "table" then return nil, "session must be a table" end

    local config = safeConfig(userConfig)
    local samples, sampleError, optionalInvalid = validateSamples(session.samples, config)
    if not samples then return nil, sampleError end

    local motion = calculateMotion(samples, config)
    local events, eventError = analyzeEvents(session.events, config)
    if not events then return nil, eventError end

    local quality = "LOW"
    if motion.sampleCoverage >= 0.95
        and motion.p95SampleGapMs <= 50
        and #samples >= 30 then
        quality = "HIGH"
    elseif motion.sampleCoverage >= 0.80
        and motion.p95SampleGapMs <= 120
        and #samples >= 10 then
        quality = "MEDIUM"
    end

    local warnings = buildWarnings(motion, events, optionalInvalid or 0, config)
    return {
        version = Analyzer.VERSION,
        baseVersion = Analyzer.BASE_VERSION,
        generatedAt = os.clock(),
        dataQuality = quality,
        motion = motion,
        events = events,
        warnings = warnings,
        configuration = config,
        limitations = {
            "Offline replay analysis only; no live-game control.",
            "Event proximity does not prove that an attempt caused or prevented a hit.",
            "Trajectory metrics are only as reliable as the supplied timestamps and positions.",
            "Client-observed replay data cannot independently separate server replication delay from rendering delay.",
        },
    }
end

function Analyzer.FormatSummary(report)
    if type(report) ~= "table"
        or type(report.motion) ~= "table"
        or type(report.events) ~= "table" then
        return nil, "invalid report"
    end

    local m, e = report.motion, report.events
    return string.format(
        "AERIS Training Replay Analyzer v%s\nQuality: %s\n" ..
        "Samples: %d | Valid segments: %d/%d | Coverage: %.1f%%\n" ..
        "Gap median/P95/max: %.2f / %.2f / %.2f ms\n" ..
        "Ball speed avg/P95/peak: %.2f / %.2f / %.2f\n" ..
        "Acceleration avg/P95: %.2f / %.2f\n" ..
        "Distance avg/min: %.2f / %.2f\n" ..
        "Heading change avg/P95: %.2f / %.2f deg\n" ..
        "Ping avg/P95: %.2f / %.2f ms | Frame time avg/P95: %.2f / %.2f ms\n" ..
        "Events: %d attempts, %d hits, %d paired, %d unmatched",
        tostring(report.version), tostring(report.dataQuality),
        m.sampleCount, m.validSegments, m.segmentCount, m.sampleCoverage * 100,
        m.medianSampleGapMs, m.p95SampleGapMs, m.maxSampleGapMs,
        m.averageBallSpeed, m.p95BallSpeed, m.peakBallSpeed,
        m.averageBallAcceleration, m.p95BallAcceleration,
        m.averageDistance, m.minimumDistance,
        m.averageHeadingChangeDegrees, m.p95HeadingChangeDegrees,
        m.averagePingMs, m.p95PingMs, m.averageFrameTimeMs, m.p95FrameTimeMs,
        e.attempts, e.hits, e.pairedCount,
        e.unmatchedAttempts + e.unmatchedHits
    )
end

function Analyzer.ExportCSV(report)
    if type(report) ~= "table" or type(report.motion) ~= "table" then
        return nil, "invalid report"
    end
    local m = report.motion
    local rows = {
        "metric,value",
        "version," .. tostring(report.version),
        "data_quality," .. tostring(report.dataQuality),
        "sample_count," .. tostring(m.sampleCount),
        "valid_segments," .. tostring(m.validSegments),
        "segment_count," .. tostring(m.segmentCount),
        "sample_coverage," .. tostring(m.sampleCoverage),
        "median_gap_ms," .. tostring(m.medianSampleGapMs),
        "p95_gap_ms," .. tostring(m.p95SampleGapMs),
        "average_ball_speed," .. tostring(m.averageBallSpeed),
        "peak_ball_speed," .. tostring(m.peakBallSpeed),
        "average_ball_acceleration," .. tostring(m.averageBallAcceleration),
        "minimum_distance," .. tostring(m.minimumDistance),
        "average_ping_ms," .. tostring(m.averagePingMs),
        "average_frame_time_ms," .. tostring(m.averageFrameTimeMs),
    }
    return table.concat(rows, "\n")
end

return Analyzer
