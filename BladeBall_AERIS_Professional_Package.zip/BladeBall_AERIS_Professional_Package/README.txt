BLADE BALL / AERIS PROFESSIONAL PACKAGE
=======================================

CONTENTS
--------
1) BASELINE_UNMODIFIED.lua
   The supplied baseline copied byte-for-byte. No gameplay, hook, remote,
   input automation, or device-spoofing behavior has been changed.

2) AERIS_TrainingReplayAnalyzer_v2_1.lua
   The supplied AERIS v2.1.0 offline replay-analysis module, kept separate.
   It accepts caller-provided timestamped Vector3 samples and event records,
   and returns descriptive motion, timing, ping, frame-time, and data-quality
   metrics. It does not capture gameplay, invoke remotes, install hooks,
   synthesize input, or control a live game.

INTEGRATION BOUNDARY
--------------------
This package intentionally keeps AERIS separate from the live Auto Parry
baseline. AERIS is an offline diagnostic module, not a live-game controller.
To use it in a legitimate Studio/training workflow, require the ModuleScript
and pass it a replay session collected by an authorized replay recorder:

    local Analyzer = require(path.To.AERIS_TrainingReplayAnalyzer_v2_1)
    local report, err = Analyzer.AnalyzeSession(replaySession)
    if not report then
        warn("AERIS analysis failed: " .. tostring(err))
    else
        print(Analyzer.FormatSummary(report))
        local csv = Analyzer.ExportCSV(report)
    end

EXPECTED SESSION SHAPE
----------------------
    {
      samples = {
        {
          t = 0.0, -- monotonic seconds; strictly increasing
          ballPosition = Vector3.new(0, 0, 0),
          playerPosition = Vector3.new(1, 0, 0),
          pingMs = 45,       -- optional
          frameTimeMs = 16.7 -- optional
        },
        -- At least 3 samples by default.
      },
      events = {
        { t = 1.25, kind = "parry_attempt" },
        { t = 1.41, kind = "hit" }
      }
    }

VALIDATION NOTES
----------------
- AERIS requires Roblox Luau/Vector3 semantics (typeof, table.create,
  Vector3 arithmetic, and os.clock).
- Sample timestamps must be finite and strictly increasing.
- Motion segments crossing large sample gaps or extreme speeds are excluded.
- Attempt-to-hit proximity is descriptive correlation, not causal proof.
- No runtime execution test was claimed because no Luau interpreter/runtime
  was available in the build environment. Static source/structure review only.

SAFETY / SCOPE
--------------
The supplied baseline contains executor-specific hooks and live-game remote
interception. This package does not extend or optimize those mechanisms.
AERIS is provided strictly for offline replay diagnostics and authorized
training-data analysis.
